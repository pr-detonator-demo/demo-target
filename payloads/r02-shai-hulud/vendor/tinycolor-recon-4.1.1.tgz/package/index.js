module.exports = (c) => c;
