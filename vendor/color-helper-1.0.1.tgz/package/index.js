module.exports = (c) => String(c).toUpperCase();
