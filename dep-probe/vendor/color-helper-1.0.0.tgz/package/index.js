module.exports = (c) => c.toUpperCase();
